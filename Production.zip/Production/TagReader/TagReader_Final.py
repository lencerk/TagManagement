
import serial, time, glob, sys, os
from multiprocessing import Process

from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtSerialPort import QSerialPort, QSerialPortInfo

import json
import requests
from requests.auth import HTTPBasicAuth
import base64

class usp_service(object):
    def __init__(self, url):
        self.url = url
        self.headers={ "Content-Type": "application/json" }
        
    def login(self, email, password):
        url = self.url + '/Users'
        payload = json.dumps({
            "email": email,
            "password": password,
            "ttl": "4838400"
        })
        response = requests.request("POST", url+"/login", headers=self.headers, data=payload)
        #print(response.text)
        if(response.status_code == 200):
            myResponse = json.loads(response.text)["id"]
        else:
            myResponse = ""
        return(myResponse)
    
    def poll(self, client, mac):
        return {'ClientId':client, "MAC":mac}
    
    def query(self, client, mac, cmd):
        return {'ClientId':client, "MAC":mac, "CMD":cmd, "Type":1}
    
    def response(self, client, mac, cmd, ref):
        return {'ClientId':client, "MAC":mac, "CMD":cmd, "Type":1, "RefId":ref}
        


class piPumps(object):
    def __init__(self):
        self.id = 0 
        self.HardwareId = 0 
        self.SoftwareId = 0 
        self.Status = 0 
        self.Enabled = False 
        self.PulsRate = 0 
        self.tank_id = 0 
        self.pumptype_id = 0 
        self.ComPort = 0 
        self.PumpTotal = 0 
        self.SiteId = 0 
        self.OldPulse = 0 
        self.Pulse = 0 
        self.OldStatus = 0 
        self.TagString = "" 
        self.FinCount = 0 
        self.Nozzle = 0 
        self.NozPrice = 0 
        self.Money = 0 
        self.Volume = 0 
        self.PresetPulse = 0 
        self.PresetVolume = 0 
        self.PulseTimeout = 0 
        self.Attendant = "" 
        self.Driver = "" 
        self.client_id = "" 
        self.ElectronicTotal = 0 
        self.TransactionId = 0 
        self.ProtocolTimer = 0 
        self.ProtocolTimeout = 0 
        self.ProtocolBaud = 0 
        self.StatusMessageId = 0 
        self.StatusMessage = "" 
        self.IsPrepay = False 
        self.SlowDownVal = 0 
        self.PinNo = "" 
        self.FleetNo = "" 
        self.Authorized = False 
        self.WebId = 0 
        self.Downloaded = True 
        self.DecimalPlaces = 0 
        self.PumpModel = 0 
        self.kbStatus = 0 
        self.kbData = ""
        self.GroupId = 0
        self.NoOfNoz = 0
        self.TankId2 = 0
        self.TankId3 = 0
        self.TankId4 = 0
        self.VitIP = ""
        self.VitHexId = 0
        self.VitEnabled = False
        self.VitPort = 0
        self.VitChannel = 0
        self.VitOdometer = 0.0
        self.VitPlate = ""
        self.VitEnginehours = 0.0
        self.VitBlocked = False
        self.VitBlockReason = ""
        self.TagEnabled = True
        self.TagPort = 0
        self.TagType = -1
        self.TagRemote = 0
        self.ClientCommand = 0
        self.ServerCommand = 0
        self.Description = ""
        self.InuseAsBypass = False
        self.DummyNoz = False
        self.AutoAuth = False
        self.VIUStatus = 0
        self.OverideType = 0
        self.OverideTag = ""
        self.DeviceId = 0
        self.TagReader = 0
        self.volume1 = 0
        self.volume2 = 0
        self.volume3 = 0
        self.tagstring1 = ""
        self.tagstring2 = ""
        self.tagstring3 = ""
        self.otp = ""
        self.priceDecimal = 1.0
        self.volumeDecimal = 100.0
        self.moneyDecimal = 100.0
        self.pplDecimal = 100.0
        self.totalsDecimal = 100.0

class MAX9097:
    """ Minimal DS2480B control and 1-wire data transfer.
    
    DS2480B control
        0xE3 : command-mode
        0xE1 : data-mode
        0xC1 : reset
        0x81/0x91 : sigle-bit-write-0/1
    """
    _MODE_CMD = 0xE3
    _MODE_DAT = 0xE1
    
    def __init__(self, port, timeout=3):
        """
        port : string, name of serial port (ex. 'COM3').
        timeout : float, [sec] timeout.
        """
        self.uart = serial.Serial(port=port, timeout=timeout)
        self.clear()
        self.mode = MAX9097._MODE_CMD
        self.cmd_reset()
        
    def clear(self):
        self.uart.send_break()
        self.uart.reset_input_buffer()
        self.uart.reset_output_buffer()
        
    def set_mode(self, mode):
        if mode != self.mode:
            self.uart.write([mode])
            self.mode = mode
            #r = self.uart.read(1)
        
    def close(self):
        self.uart.close()
        
    def cmd_reset(self):
        self.set_mode(MAX9097._MODE_CMD)
        self.uart.write([0xC1]) # reset-pulse
        r = self.uart.read()
        if r != b'\xCD':
            "ERROR"
        
    def cmd_write_bit(self, v):
        self.set_mode(MAX9097._MODE_CMD)
        if v != 0:
            self.uart.write([0x91]) # "on" bit
        else:
            self.uart.write([0x81]) # "off" bit
        val = self.uart.read(1)
        return int(val[0]) & 1
        
    def cmd_read_bit(self):
        return self.cmd_write_bit(1)
        
    def dat_write(self, buf):
        def _w(v):
            self.uart.write([v])
            return self.uart.read(1)
        self.set_mode(MAX9097._MODE_DAT)
        return [_w(a) for a in buf]
        
    def dat_read(self, n):
        return self.dat_write([0xFF]*n)

    def crc_check(self, rBytes):
        crc = 0
        for b in rBytes:
            if(b < 0):
                b += 256    
            for i in range(8):
                odd = ((b^crc) & 1) == 1
                crc >>= 1
                b >>= 1
                if(odd):
                    crc ^= 0x8C
        return crc
        
class max9097TagReader(object):
    def __init__(self):
        print("INFO - max9097TagReader started")
        self.tagString = "0000000000000000"

    # Define MAX9097 BUS
    def connect(self, COMport='/dev/ttyUSB0', timeout=0.03):
        self.bus = MAX9097(COMport, timeout)
        print("INFO - OneWire connected on port : %s" % COMport)

    def readTagReader(self):
        try:
            self.bus.mode = self.bus._MODE_CMD
            self.bus.dat_write([0x33])           # read-rom
            ans = self.bus.dat_read(8)           # little-endian (family + SN[6] + CRC)
            if(any(x=='' for x in ans)):
                print("WARNING - Invalid Rx : %s" % ans)
                time.sleep(1.0)
            else:
                barray = [int.from_bytes(x, byteorder='little') for x in ans]
                crc = self.bus.crc_check(barray)
                if((ans[0] == b'\x01' or ans[0] == b'\x08') and crc == 0):
                    rcv = ['%02X'%a for a in reversed(barray)]
                    self.tagString = rcv[7]+rcv[6]+rcv[5]+rcv[4]+rcv[3]+rcv[2]+rcv[1]+rcv[0]
                    print("TAG - %s" % self.tagString)
            self.bus.clear()
        except:
            print("ERROR- readTagReader : %s" % sys.exc_info()[1])

    def clearTagBuffer(self):
        self.tagString = "0000000000000000"

    def isTagData(self):
        isTag = False
        if(self.tagString != "0000000000000000"):
            isTag = True
        return isTag

    def getTagData(self, pData):
        sTag = self.tagString
        pData.TagString = sTag
        #print("INFO - Tag No - %s" % sTag)
        self.clearTagBuffer()
        return True
class Ui_MainWindow(object):
    def __init__(self):
        self.oPumps = piPumps() 
        self.oTagReader = max9097TagReader()
        self.timer = QtCore.QTimer(interval=30, timeout=self.tControl)
        self.t = time.time()

    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(488, 386)
        MainWindow.setMinimumSize(QtCore.QSize(488, 386))
        MainWindow.setMaximumSize(QtCore.QSize(488, 386))

        # Apply custom styles
        self.apply_styles(MainWindow)

        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        MainWindow.setCentralWidget(self.centralwidget)

        self.stackedWidget = QtWidgets.QStackedWidget(self.centralwidget)
        self.stackedWidget.setGeometry(QtCore.QRect(40, 110, 411, 221))
        self.stackedWidget.setObjectName("stackedWidget")

        # Directly setting up the Tag Reader page
        self.page3 = QtWidgets.QWidget()
        self.page3.setObjectName("page3")
        self.tagEdit_2 = QtWidgets.QLineEdit(self.page3)
        self.tagEdit_2.setGeometry(QtCore.QRect(160, 120, 230, 40))
        self.tagEdit_2.setFont(QtGui.QFont('Segoe UI', 12))
        self.tagEdit_2.setCursor(QtGui.QCursor(QtCore.Qt.BlankCursor))
        self.tagEdit_2.setText("")
        self.tagEdit_2.setReadOnly(True)
        self.tagEdit_2.setObjectName("tagEdit_2")

        self.tagLbl_2 = QtWidgets.QLabel(self.page3)
        self.tagLbl_2.setGeometry(QtCore.QRect(50, 120, 80, 40))
        self.tagLbl_2.setFont(QtGui.QFont('Segoe UI', 16, QtGui.QFont.Bold))
        self.tagLbl_2.setObjectName("tagLbl_2")

        self.comboBoxComs = QtWidgets.QComboBox(self.page3)
        self.comboBoxComs.setGeometry(QtCore.QRect(160, 60, 80, 25))
        self.comboBoxComs.setObjectName("comboBoxComs")

        self.serialLbl = QtWidgets.QLabel(self.page3)
        self.serialLbl.setGeometry(QtCore.QRect(160, 10, 171, 31))
        self.serialLbl.setFont(QtGui.QFont('Segoe UI', 10))
        self.serialLbl.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.serialLbl.setObjectName("serialLbl")

        self.infoLbl_3 = QtWidgets.QLabel(self.page3)
        self.infoLbl_3.setGeometry(QtCore.QRect(160, 180, 220, 30))
        self.infoLbl_3.setFont(QtGui.QFont('Segoe UI', 10))
        self.infoLbl_3.setStyleSheet("color: red;")
        self.infoLbl_3.setObjectName("infoLbl_3")

        self.connectButton = QtWidgets.QPushButton(self.page3)
        self.connectButton.setGeometry(QtCore.QRect(260, 60, 75, 25))
        self.connectButton.setCheckable(False)
        self.connectButton.setObjectName("connectButton")

        self.stackedWidget.addWidget(self.page3)

        # Add logo label and central widget setup
        self.logoLbl = QtWidgets.QLabel(self.centralwidget)
        self.logoLbl.setGeometry(QtCore.QRect(132, 10, 223, 83))
        self.logoLbl.setFont(QtGui.QFont('Segoe UI', 28))
        self.logoLbl.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.logoLbl.setText("")
        self.logoLbl.setObjectName("logoLbl")

        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 488, 21))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)

        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        self.stackedWidget.setCurrentWidget(self.page3)  # Directly show the tag reader page
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def apply_styles(self, MainWindow):
        style = """
            QWidget {
                background-color: #f0f0f0;
                border-radius: 15px;
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                font-size: 14px;
            }
            QLabel {
                color: #333;
                font-weight: bold;
            }
            QLineEdit {
                font-size: 14px;
                border: 1px solid #cc5500;
                border-radius: 5px;
                padding: 5px;
                background-color: white;
                color: #333;
            }
            QComboBox {
                font-size: 14px;
                border: 1px solid #cc5500;
                border-radius: 5px;
                padding: 5px;
            }
            QPushButton {
                background-color: #cc5500;
                color: white;
                font-size: 14px;
                border-radius: 10px;
                padding: 5px 10px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #ff6600;
            }
            QStatusBar {
                background-color: #f0f0f0;
                border-top: 1px solid #cc5500;
            }
            QMenuBar {
                background-color: #f0f0f0;
            }
        """
        MainWindow.setStyleSheet(style)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "FMA Tag Reader"))
        self.tagLbl_2.setText(_translate("MainWindow", "Tag"))
        self.serialLbl.setText(_translate("MainWindow", "Serial Settings"))
        self.infoLbl_3.setText(_translate("MainWindow", ""))
        self.connectButton.setText(_translate("MainWindow", "Connect"))

        pixmap = QtGui.QPixmap(self.resource_path("logo.png"))
        pixmap = pixmap.scaled(self.logoLbl.width(), self.logoLbl.height(), QtCore.Qt.KeepAspectRatio)
        self.logoLbl.setPixmap(pixmap)
        self.logoLbl.setAlignment(QtCore.Qt.AlignCenter)

        self.attachUIcontrol()

    def attachUIcontrol(self):
        self.connectButton.clicked.connect(self.connect)
        self.comboBoxComs.addItems(self.getPortNames())

    def resource_path(self, relative_path):
        base_path = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
        return os.path.join(base_path, relative_path)

    def connect(self):
        self.connectButton.setEnabled(False)
        self.oTagReader.connect(self.getPortSelected())  
        self.timer.start()

    def tControl(self):
        self.oTagReader.readTagReader()
        if self.oTagReader.isTagData():
            self.oTagReader.getTagData(self.oPumps)
            self.infoLbl_3.setText("New Tag Detected!!!")
            self.tagEdit_2.setText(self.oPumps.TagString)
            self.t = time.time() + 2
        elif time.time() > self.t:
            self.infoLbl_3.setText("Present Next Tag")
            self.t = time.time()

    def getPortNames(self):
        ports = [port.portName() for port in QSerialPortInfo().availablePorts()]
        return ports
    
    def getPortSelected(self):
        return self.comboBoxComs.currentText()

    def tControl(self):
        self.oTagReader.readTagReader()
        if self.oTagReader.isTagData():
            self.oTagReader.getTagData(self.oPumps)
            self.infoLbl_3.setText("New Tag Detected!!!")
            self.tagEdit_2.setText(self.oPumps.TagString)
            self.t = time.time() + 2
    
            # Show the Tag Action Window
            self.tagActionWindow = TagActionWindow()
            self.tagActionWindow.show()
        elif time.time() > self.t:
            self.infoLbl_3.setText("Present Next Tag")
            self.t = time.time()
    
    



def getPortName():
    if sys.platform.startswith('win'):
        ports = ['COM%s' % (i + 1) for i in range(256)]
    elif sys.platform.startswith('linux') or sys.platform.startswith('cygwin'):
        # this excludes your current terminal "/dev/tty"
        ports = glob.glob('/dev/tty[A-Za-z]*')
    elif sys.platform.startswith('darwin'):
        ports = glob.glob('/dev/tty.*')
    else:
        raise EnvironmentError('Unsupported platform')

    result = []
    for port in ports:
        try:
            s = serial.Serial(port)
            s.close()
            result.append(port)
        except (OSError, serial.SerialException):
            pass
    return result


class TagActionWindow(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Tag Actions")
        self.setGeometry(100, 100, 300, 150)
        
        # Set up the layout
        layout = QtWidgets.QVBoxLayout()
        
        # Create buttons
        self.queryButton = QtWidgets.QPushButton("Query Tag")
        self.createButton = QtWidgets.QPushButton("Create Tag")
        self.deleteButton = QtWidgets.QPushButton("Delete Tag")
        
        # Add buttons to the layout
        layout.addWidget(self.queryButton)
        layout.addWidget(self.createButton)
        layout.addWidget(self.deleteButton)
        
        self.setLayout(layout)
        
        # Apply modern styling
        self.apply_styles()

        # Connect buttons to their respective functions
        self.queryButton.clicked.connect(self.query_tag)
        self.createButton.clicked.connect(self.create_tag)
        self.deleteButton.clicked.connect(self.delete_tag)

    def apply_styles(self):
        style = """
            QWidget {
                background-color: #f0f0f0;
                border-radius: 10px;
                padding: 10px;
            }
            QPushButton {
                background-color: #cc5500;
                color: white;
                font-size: 14px;
                border-radius: 10px;
                padding: 10px;
                margin: 5px;
            }
            QPushButton:hover {
                background-color: #ff6600;
            }
            QPushButton:pressed {
                background-color: #cc5500;
                border-style: inset;
            }
        """
        self.setStyleSheet(style)

    def query_tag(self):
        print("Query Tag clicked!")
        # Implement the query functionality here

    def create_tag(self):
        print("Create Tag clicked!")
        # Implement the create functionality here

    def delete_tag(self):
        print("Delete Tag clicked!")
        # Implement the delete functionality here


        
if __name__ == "__main__":

    #ports = getPortName()

    
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())

